$setwallpapersrc = @"
using System.Runtime.InteropServices;

public class Wallpaper
{
  public const int SetDesktopWallpaper = 20;
  public const int UpdateIniFile = 0x01;
  public const int SendWinIniChange = 0x02;
  [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
  private static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
  public static void SetWallpaper(string path)
  {
    SystemParametersInfo(SetDesktopWallpaper, 0, path, UpdateIniFile | SendWinIniChange);
  }
}
"@
Add-Type -TypeDefinition $setwallpapersrc

function Test-IsShortcut {
    param (
        [string]$FilePath
    )

    $extension = [System.IO.Path]::GetExtension($FilePath)
    return ($extension -eq '.lnk')
}

function Move-DesktopFilesAndCreateShortcuts {
    param (
        [string]$DestinationFolderPath,
		[string]$NewIconPath
    )

    # Define the path to the desktop and get all files
    $desktopPath = [System.IO.Path]::Combine($env:USERPROFILE, 'Desktop')
    $files = Get-ChildItem -Path $desktopPath -File

    # Create the destination folder if it doesn't exist
    if (-not (Test-Path -Path $DestinationFolderPath)) {
        New-Item -ItemType Directory -Path $DestinationFolderPath -Force
    }

    # Move each file to the destination folder and create a shortcut on the desktop
    foreach ($file in $files) {
		$isShortcut = Test-IsShortcut -FilePath $file.FullName
		if ($isShortcut) {
			$shell = New-Object -ComObject WScript.Shell
			$shortcut = $shell.CreateShortcut($file.FullName)
			$shortcut.IconLocation = $NewIconPath
			$shortcut.Save()
		} else {
			$destinationFilePath = Join-Path $DestinationFolderPath $file.Name
			Move-Item -Path $file.FullName -Destination $destinationFilePath

			# Create a shortcut on the desktop
			$shell = New-Object -ComObject WScript.Shell
			$shortcut = $shell.CreateShortcut("$desktopPath\$($file.BaseName).lnk")
			$shortcut.TargetPath = $destinationFilePath
			$shortcut.IconLocation = $NewIconPath
			$shortcut.Save()	
		}
        
    }

    Write-Host "Files moved from desktop to $DestinationFolderPath, and shortcuts created on desktop."
}

function Replace-USBConnectionSounds {
    param (
        [string]$ConnectReplacementPath,
        [string]$DisconnectReplacementPath
    )

    reg add HKEY_CURRENT_USER\AppEvents\Schemes\Apps\.Default\DeviceConnect\.Current\ /t REG_SZ /d $ConnectReplacementPath /f
	reg add HKEY_CURRENT_USER\AppEvents\Schemes\Apps\.Default\DeviceDisconnect\.Current\ /t REG_SZ /d $DisconnectReplacementPath /f
}

# Set wallpaper
[Wallpaper]::SetWallpaper("$env:TMP\cat.jpg")


# Set desktop icons:
Move-DesktopFilesAndCreateShortcuts -DestinationFolderPath "C:\Users\Public\Old Desktop" -NewIconPath "$env:TMP\cat.ico"

# Set USB sounds
Replace-USBConnectionSounds -ConnectReplacementPath "C:\Users\Public\Sagiware\Yamete Kudasai.wav" -DisconnectReplacementPath "$env:TMP\Ahh.wav"
